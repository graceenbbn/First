# ============================================================
# 🛡️ SAFE-DRIVE TEMBALANG
# Aplikasi Peta Titik Bahaya Lalu Lintas Berbasis Streamlit
# ============================================================
# Fitur Utama:
#   1. HOME     - Peta interaktif titik bahaya + sensor GPS live
#   2. RUTE     - Navigasi rute dengan deteksi bahaya di jalur
#   3. DATA     - Tabel database titik bahaya terverifikasi
#   4. LAPOR    - Upload foto untuk melaporkan titik bahaya baru
#   5. ADMIN    - Panel moderasi laporan (approve/tolak/hapus)
#   6. ALARM    - Peringatan otomatis saat mendekati titik bahaya
# ============================================================

# ─────────────────────────────────────────────────────────────
# BAGIAN 1: IMPORT LIBRARY
# ─────────────────────────────────────────────────────────────
import streamlit as st                          # Framework UI web
import pandas as pd                             # Manipulasi data CSV
import folium                                   # Buat peta interaktif
from folium import plugins                      # Plugin folium (LocateControl, dll)
import os                                       # Operasi file & folder
import requests                                 # HTTP request ke OSRM (routing)
import re                                       # Regex untuk baca koordinat dari teks
import pytesseract                              # OCR: baca teks dari gambar
import json                                     # Konversi data ke JSON (untuk JS)
import streamlit.components.v1 as components    # Injeksi HTML/JS ke Streamlit
from PIL import Image                           # Buka & proses gambar
from streamlit_folium import st_folium          # Render peta folium di Streamlit
from streamlit_geolocation import streamlit_geolocation  # Ambil GPS dari browser
from geopy.distance import geodesic             # Hitung jarak dua koordinat (meter)
from geopy.geocoders import ArcGIS              # Geocoding: nama → koordinat
from streamlit_autorefresh import st_autorefresh  # Auto-refresh halaman berkala


# ─────────────────────────────────────────────────────────────
# BAGIAN 2: KONFIGURASI HALAMAN STREAMLIT
# ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Safe-Drive",   # Judul tab browser
    layout="centered",          # Layout tengah (bukan wide)
    page_icon="🛡️"             # Ikon tab browser
)

# Sembunyikan elemen bawaan Streamlit (menu, footer, header)
# agar tampilan lebih bersih seperti mobile app
hide_st_style = """
<style>
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}
.block-container {
    padding-top: 1rem;
    padding-bottom: 1rem;
}
</style>
"""
st.markdown(hide_st_style, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# BAGIAN 3: MANAJEMEN DATA (CSV)
# ─────────────────────────────────────────────────────────────
# Semua titik bahaya disimpan di file CSV lokal ini
FILE_CSV = 'hasil_survei_tembalang.csv'

def load_csv():
    """
    Memuat data titik bahaya dari file CSV.
    Jika file belum ada → buat DataFrame kosong.
    Jika kolom 'status'/'foto' belum ada → tambahkan otomatis.
    """
    if os.path.exists(FILE_CSV):
        df = pd.read_csv(FILE_CSV)
        # Pastikan kolom wajib ada (backward compatibility)
        if 'status' not in df.columns:
            df['status'] = 'approved'
        if 'foto' not in df.columns:
            df['foto'] = None
        df.to_csv(FILE_CSV, index=False)
        return df
    else:
        # Buat DataFrame kosong dengan kolom standar
        return pd.DataFrame(columns=['lokasi', 'lat', 'lon', 'pesan', 'status', 'foto'])

# Load semua data dari CSV
df_bahaya = load_csv()

# Filter hanya data yang sudah disetujui admin (status = 'approved')
# Data 'pending' tidak ditampilkan di peta publik
df_aktif = df_bahaya[df_bahaya['status'] == 'approved'].copy() if not df_bahaya.empty else pd.DataFrame()


# ─────────────────────────────────────────────────────────────
# BAGIAN 4: FUNGSI OCR - BACA KOORDINAT DARI GAMBAR
# ─────────────────────────────────────────────────────────────
def read_coordinates_from_image(img):
    """
    Membaca teks koordinat GPS dari gambar menggunakan OCR (pytesseract).
    
    Cara kerja:
    1. Gambar diubah ke teks oleh pytesseract
    2. Regex mencari semua angka desimal panjang (koordinat GPS)
    3. Tentukan mana latitude (-90 s/d 90) dan mana longitude (> 90)
    
    Parameter:
        img : PIL.Image - gambar yang diunggah user
    
    Returns:
        (lat, lon) : tuple float, atau (None, None) jika tidak ditemukan
    """
    try:
        # Jalankan OCR → hasilkan string teks dari gambar
        text = pytesseract.image_to_string(img)
        
        # Cari semua angka desimal dengan minimal 4 digit di belakang koma
        # Contoh cocok: -7.049872, 110.441500
        matches = re.findall(r'-?\d{1,3}\.\d{4,}', text)
        
        if len(matches) >= 2:
            val1 = float(matches[0])
            val2 = float(matches[1])
            # Latitude: antara -90 dan 90
            # Longitude: biasanya lebih dari 90 (untuk Indonesia ~110)
            if abs(val1) < 90 and abs(val2) > 90:
                return val1, val2       # val1=lat, val2=lon
            elif abs(val2) < 90 and abs(val1) > 90:
                return val2, val1       # val2=lat, val1=lon
        return None, None
    except:
        return None, None


# ─────────────────────────────────────────────────────────────
# BAGIAN 5: INISIALISASI SESSION STATE
# ─────────────────────────────────────────────────────────────
# Session state menyimpan data antar-rerun Streamlit
# (seperti variabel global yang tetap hidup selama sesi)

if 'halaman' not in st.session_state:
    st.session_state.halaman = 'Home'           # Halaman aktif saat ini

if 'rute_data' not in st.session_state:
    st.session_state.rute_data = None           # Data rute navigasi aktif

if 'role' not in st.session_state:
    st.session_state.role = 'User'              # Role: 'User' atau 'Admin'

if 'is_navigating' not in st.session_state:
    st.session_state.is_navigating = False      # Status navigasi aktif/tidak


# ─────────────────────────────────────────────────────────────
# BAGIAN 6: HEADER APLIKASI
# ─────────────────────────────────────────────────────────────
st.markdown(
    "<h3 style='text-align: center; color: #E74C3C; margin-bottom: 10px;'>🛡️ Safe-Drive</h3>",
    unsafe_allow_html=True
)


# ─────────────────────────────────────────────────────────────
# BAGIAN 7: NAVIGASI MENU (TOMBOL)
# ─────────────────────────────────────────────────────────────
# Saat navigasi aktif, menu dikunci agar pengemudi tidak terdistraksi
if not st.session_state.is_navigating:
    # Tampilkan 5 tombol navigasi dalam satu baris
    col1, col2, col3, col4, col5 = st.columns(5)
    
    if col1.button("🏠 Home", use_container_width=True):
        st.session_state.halaman = 'Home'
    if col2.button("🗺️ Rute", use_container_width=True):
        st.session_state.halaman = 'Rute'
    if col3.button("📂 Data", use_container_width=True):
        st.session_state.halaman = 'Data'
    if col4.button("➕ Lapor", use_container_width=True):
        st.session_state.halaman = 'Lapor'
    
    # Kolom ke-5: tampilkan "Admin" jika sudah login, "Login" jika belum
    if st.session_state.role == 'Admin':
        if col5.button("🛡️ Admin", use_container_width=True):
            st.session_state.halaman = 'Admin'
    else:
        if col5.button("🔐 Login", use_container_width=True):
            st.session_state.halaman = 'Login'

else:
    # Mode navigasi aktif: tampilkan peringatan dan tombol selesai
    st.warning("⚠️ **NAVIGASI SEDANG AKTIF.** Selesaikan perjalanan untuk membuka menu!")
    if st.button("🛑 SELESAIKAN NAVIGASI"):
        st.session_state.is_navigating = False
        st.session_state.rute_data = None
        st.rerun()

st.markdown("---")


# ─────────────────────────────────────────────────────────────
# BAGIAN 8: SENSOR GPS - AMBIL POSISI USER
# ─────────────────────────────────────────────────────────────
# GPS hanya diambil di halaman yang membutuhkan lokasi user
user_lat, user_lon = None, None

if st.session_state.halaman in ['Home', 'Lapor', 'Rute']:
    col_teks, col_gps = st.columns([1, 2])
    col_teks.markdown("**📡 Sensor GPS Anda:**")
    
    with col_gps:
        # Komponen ini meminta izin GPS dari browser user
        # Mengembalikan dict {'latitude': ..., 'longitude': ...}
        location = streamlit_geolocation()
        user_lat = location.get('latitude')
        user_lon = location.get('longitude')


# ─────────────────────────────────────────────────────────────
# BAGIAN 9: FUNGSI ALARM BAHAYA (JavaScript)
# ─────────────────────────────────────────────────────────────
def inject_super_alarm():
    """
    Menyuntikkan kode JavaScript ke halaman untuk:
    1. Memantau posisi GPS user secara real-time (watchPosition)
    2. Menghitung jarak ke setiap titik bahaya
    3. Jika jarak < 200 meter → tampilkan overlay merah + getarkan HP
    4. User bisa menutup overlay dengan mengetuk layar
    
    Data titik bahaya dikirim dari Python ke JS via JSON.
    Alarm menggunakan Web Geolocation API browser (bukan Python).
    """
    if df_aktif.empty:
        return  # Tidak ada titik bahaya → tidak perlu alarm
    
    # Ubah DataFrame ke JSON untuk dikirim ke JavaScript
    hazards_json = json.dumps(
        df_aktif[['lat', 'lon', 'pesan', 'lokasi']].to_dict(orient='records')
    )
    
    components.html(f"""
    <script>
    // ── Data titik bahaya dari Python ──
    const hazards = {hazards_json};

    // ── Fungsi hitung jarak (Haversine Formula) dalam meter ──
    function getDistance(lat1, lon1, lat2, lon2) {{
        const R = 6371000; // Radius bumi dalam meter
        const dLat = (lat2-lat1) * (Math.PI/180);
        const dLon = (lon2-lon1) * (Math.PI/180);
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) 
                + Math.cos(lat1*(Math.PI/180)) * Math.cos(lat2*(Math.PI/180)) 
                * Math.sin(dLon/2) * Math.sin(dLon/2);
        return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));
    }}

    let alarmActive = false;
    let overlayDiv = null;
    const parentDoc = window.parent.document;

    // ── Mulai pantau GPS real-time ──
    if (navigator.geolocation) {{
        navigator.geolocation.watchPosition(
            function(pos) {{
                const uLat = pos.coords.latitude;
                const uLon = pos.coords.longitude;
                
                let nearHazard = false;
                let msg = "";
                let locName = "";
                let sisaJarak = 0;
                
                // Cek jarak ke semua titik bahaya
                for(let i=0; i<hazards.length; i++) {{
                    const dist = getDistance(uLat, uLon, hazards[i].lat, hazards[i].lon);
                    
                    // Ambang batas: 200 meter
                    if(dist < 200) {{
                        nearHazard = true;
                        msg = hazards[i].pesan;
                        locName = hazards[i].lokasi;
                        sisaJarak = Math.round(dist);
                        break;
                    }}
                }}
                
                // ── Aktifkan alarm jika belum aktif ──
                if (nearHazard && !alarmActive) {{
                    alarmActive = true;
                    
                    // Getarkan HP (pola: 1 detik on, 0.5s off, 1s on)
                    if(navigator.vibrate) navigator.vibrate([1000, 500, 1000, 500, 1000]);
                    
                    // Mainkan suara peringatan
                    const audio = new Audio('https://www.soundjay.com/buttons/beep-01a.mp3');
                    audio.play().catch(e => console.log("Audio diblokir browser"));
                    
                    // Buat overlay layar merah penuh
                    overlayDiv = parentDoc.createElement('div');
                    overlayDiv.style.cssText = `
                        position:fixed; top:0; left:0;
                        width:100vw; height:100vh;
                        background-color:rgba(231,76,60,0.95);
                        z-index:999999;
                        display:flex; flex-direction:column;
                        align-items:center; justify-content:center;
                        color:white; text-align:center;
                        cursor:pointer;
                    `;
                    overlayDiv.innerHTML = 
                        '<h1 style="font-size:3rem;margin:0;animation:blinker 0.4s linear infinite;">⚠️ AWAS BAHAYA ⚠️</h1>' +
                        '<h2 style="margin:10px 0;">Sisa ' + sisaJarak + ' m ke ' + locName + '</h2>' +
                        '<p style="font-size:1.5rem;font-style:italic;margin-bottom:30px;">"' + msg + '"</p>' +
                        '<p style="font-size:1rem; border:2px solid white; padding:10px 20px; border-radius:10px;">👇 Ketuk layar untuk menutup peringatan 👇</p>';
                    
                    // CSS animasi kedip
                    let style = parentDoc.createElement('style');
                    style.innerHTML = '@keyframes blinker {{ 50% {{ opacity: 0; }} }}';
                    overlayDiv.appendChild(style);
                    
                    // Klik overlay → tutup peringatan
                    overlayDiv.onclick = function() {{
                        this.style.display = 'none';
                    }};
                    
                    parentDoc.body.appendChild(overlayDiv);
                    
                // ── Matikan alarm jika sudah menjauh ──
                }} else if (!nearHazard && alarmActive) {{
                    alarmActive = false;
                    if(overlayDiv) {{
                        parentDoc.body.removeChild(overlayDiv);
                        overlayDiv = null;
                    }}
                }}
            }},
            function(err) {{ console.log("GPS Error:", err); }},
            {{enableHighAccuracy: true, maximumAge: 2000, timeout: 5000}}
        );
    }}
    </script>
    """, height=0, width=0)  # height=0 agar tidak makan ruang UI


# ─────────────────────────────────────────────────────────────
# BAGIAN 10: HALAMAN LOGIN ADMIN
# ─────────────────────────────────────────────────────────────
if st.session_state.halaman == 'Login':
    st.subheader("🔐 Login Admin")
    
    with st.form("form_login"):
        pwd = st.text_input("Password", type="password")
        submit_login = st.form_submit_button("Masuk")
    
    if submit_login:
        if pwd == "admin123":
            # Login berhasil → set role Admin dan pindah ke panel admin
            st.session_state.role = 'Admin'
            st.session_state.halaman = 'Admin'
            st.rerun()
        else:
            st.error("Password salah!")


# ─────────────────────────────────────────────────────────────
# BAGIAN 11: HALAMAN HOME (PETA UTAMA)
# ─────────────────────────────────────────────────────────────
elif st.session_state.halaman == 'Home':
    # Auto-refresh setiap 3 detik untuk update posisi GPS
    st_autorefresh(interval=3000, key="home_refresh")
    
    # Aktifkan sistem alarm JavaScript
    inject_super_alarm()
    
    # Buat peta folium berpusat di kawasan Tembalang, Semarang
    m = folium.Map(location=[-7.049, 110.441], zoom_start=15)
    
    # Tambahkan tombol "Lokasi Saya" di pojok kanan bawah
    plugins.LocateControl(
        auto_start=True,
        position='bottomright',
        strings={'title': 'Lokasi Saya', 'popup': 'Anda di sini'},
        flyTo=True
    ).add_to(m)
    
    # Plot semua titik bahaya yang sudah disetujui
    for _, p in df_aktif.iterrows():
        folium.Marker(
            location=[p['lat'], p['lon']],
            popup=p['lokasi'],          # Klik marker → nama lokasi
            tooltip=p['pesan'],          # Hover → pesan peringatan
            icon=folium.Icon(color='red', icon='exclamation-triangle')
        ).add_to(m)
    
    # Plot posisi user (jika GPS sudah aktif)
    if user_lat and user_lon:
        folium.Marker(
            location=[user_lat, user_lon],
            popup="Posisi Anda",
            icon=folium.Icon(color='blue')
        ).add_to(m)
    
    # Render peta di halaman Streamlit
    st_folium(m, width=700, height=450, returned_objects=[])


# ─────────────────────────────────────────────────────────────
# BAGIAN 12: HALAMAN RUTE (NAVIGASI)
# ─────────────────────────────────────────────────────────────
elif st.session_state.halaman == 'Rute':
    st.subheader("📍 Navigasi Rute Live")
    
    # ── Sub-bagian A: Form input tujuan (sebelum navigasi dimulai) ──
    if not st.session_state.is_navigating:
        st.info("Ketik lokasi tujuan. Rute akan otomatis memindai bahaya.")
        
        with st.form("form_cek_rute"):
            tujuan = st.text_input("Mau ke mana? (Contoh: UNDIP Tembalang)")
            submit_rute = st.form_submit_button("Cari Rute & Mulai Jalan")
        
        if submit_rute and tujuan:
            if not user_lat or not user_lon:
                st.error("⚠️ Tolong klik ikon Target (Sensor GPS) di atas dulu sebelum mencari rute!")
            else:
                # Gunakan ArcGIS Geocoder untuk ubah nama → koordinat
                geolocator = ArcGIS()
                
                with st.spinner("Menganalisis tujuan dari lokasi Anda..."):
                    try:
                        # Tambahkan konteks wilayah agar geocoding lebih akurat
                        query_lokasi = f"{tujuan}, Semarang, Jawa Tengah, Indonesia"
                        lokasi_tujuan = geolocator.geocode(query_lokasi)
                        
                        if lokasi_tujuan:
                            # Simpan data rute ke session state
                            st.session_state.rute_data = {
                                'nama_tujuan': lokasi_tujuan.address,
                                'dest_lat': lokasi_tujuan.latitude,
                                'dest_lon': lokasi_tujuan.longitude
                            }
                            st.session_state.is_navigating = True
                            st.rerun()
                        else:
                            st.error("Lokasi tidak ditemukan.")
                    except Exception as e:
                        st.error("Terjadi kesalahan sistem pencarian.")
    
    # ── Sub-bagian B: Tampilan navigasi aktif ──
    if st.session_state.is_navigating and st.session_state.rute_data:
        # Auto-refresh 3 detik untuk update posisi
        st_autorefresh(interval=3000, key="rute_refresh")
        
        # Aktifkan alarm bahaya
        inject_super_alarm()
        
        rd = st.session_state.rute_data
        st.success(f"Menuju: {rd['nama_tujuan']}")
        
        # Gunakan posisi GPS atau fallback ke koordinat default Tembalang
        start_lat = user_lat if user_lat else -7.049000
        start_lon = user_lon if user_lon else 110.441000
        
        # Buat peta navigasi
        m_rute = folium.Map(location=[start_lat, start_lon], zoom_start=15)
        plugins.LocateControl(
            auto_start=True, position='bottomright',
            strings={'title': 'Lokasi', 'popup': 'Anda di sini'}, flyTo=True
        ).add_to(m_rute)
        
        # ── Request rute dari OSRM (Open Source Routing Machine) ──
        # OSRM adalah API routing gratis berbasis OpenStreetMap
        url = (
            f"http://router.project-osrm.org/route/v1/driving/"
            f"{start_lon},{start_lat};"
            f"{rd['dest_lon']},{rd['dest_lat']}"
            f"?overview=full&geometries=geojson&alternatives=2"
        )
        
        try:
            res = requests.get(url, timeout=10)
            
            if res.status_code == 200:
                semua_rute = res.json().get("routes", [])
                
                if semua_rute:
                    rute_utama = semua_rute[0]
                    route_coords = rute_utama["geometry"]["coordinates"]
                    # route_coords berformat: [[lon, lat], [lon, lat], ...]
                    
                    # ── Deteksi titik bahaya di sepanjang rute ──
                    bahaya_dilewati = []
                    for _, p in df_aktif.iterrows():
                        for coord in route_coords:
                            # coord = [lon, lat] → perhatikan urutan terbalik!
                            jarak = geodesic(
                                (p['lat'], p['lon']),    # titik bahaya
                                (coord[1], coord[0])     # titik di rute
                            ).meters
                            
                            if jarak < 200:  # Dalam radius 200 meter
                                bahaya_dilewati.append(p.to_dict())
                                break  # Cukup 1 titik match per bahaya
                    
                    # ── Warna garis rute: merah=bahaya, biru=aman ──
                    warna = '#E74C3C' if bahaya_dilewati else '#0078FF'
                    
                    folium.GeoJson(
                        rute_utama["geometry"],
                        style_function=lambda x, c=warna: {
                            'color': c, 'weight': 7, 'opacity': 0.8
                        }
                    ).add_to(m_rute)
                    
                    # Tampilkan peringatan & marker bahaya jika ada
                    if bahaya_dilewati:
                        st.error(f"⚠️ RUTE MENGARAH KE DAERAH RAWAN! (Garis Merah)")
                        for b in bahaya_dilewati:
                            folium.Marker(
                                [b['lat'], b['lon']],
                                tooltip=b['pesan'],
                                icon=folium.Icon(color='red', icon='exclamation-triangle')
                            ).add_to(m_rute)
                    else:
                        st.success("✅ Rute Terpantau Aman! (Garis Biru)")
        except Exception as e:
            st.warning("Tidak bisa mengambil data rute. Cek koneksi internet.")
        
        # Marker tujuan (hijau)
        folium.Marker(
            [rd['dest_lat'], rd['dest_lon']],
            popup=rd['nama_tujuan'],
            icon=folium.Icon(color='green', icon='flag')
        ).add_to(m_rute)
        
        # Marker posisi user (biru)
        if user_lat and user_lon:
            folium.Marker(
                [user_lat, user_lon],
                popup="Posisi Anda",
                icon=folium.Icon(color='blue')
            ).add_to(m_rute)
        
        # Render peta navigasi
        st_folium(m_rute, width=700, height=450, returned_objects=[])


# ─────────────────────────────────────────────────────────────
# BAGIAN 13: HALAMAN DATA (TABEL DATABASE)
# ─────────────────────────────────────────────────────────────
elif st.session_state.halaman == 'Data':
    st.subheader("📊 Database Titik Bahaya Terverifikasi")
    
    if not df_aktif.empty:
        # Hapus kolom internal sebelum ditampilkan ke publik
        df_tampil = df_aktif.drop(columns=['jarak', 'status', 'foto'], errors='ignore')
        st.dataframe(df_tampil, use_container_width=True)
    else:
        st.info("Belum ada data titik bahaya yang disetujui.")


# ─────────────────────────────────────────────────────────────
# BAGIAN 14: HALAMAN LAPOR (PELAPORAN TITIK BAHAYA BARU)
# ─────────────────────────────────────────────────────────────
elif st.session_state.halaman == 'Lapor':
    st.subheader("📸 Pelaporan Berbasis Teks Koordinat Foto")
    st.warning(
        "Gunakan aplikasi kamera GPS. "
        "Mesin akan membaca teks koordinat yang tertulis di foto!"
    )
    
    # Widget upload foto
    foto_upload = st.file_uploader("Pilih File Foto Kejadian", type=['jpg', 'jpeg', 'png'])
    
    if foto_upload is not None:
        try:
            # Buka gambar dengan Pillow
            img = Image.open(foto_upload)
            
            # Jalankan OCR untuk baca koordinat
            with st.spinner("AI sedang membaca teks koordinat di foto Anda..."):
                exif_lat, exif_lon = read_coordinates_from_image(img)
            
            if exif_lat and exif_lon:
                st.success(f"✅ AI Berhasil membaca teks! (Lat: {exif_lat:.5f}, Lon: {exif_lon:.5f})")
                
                # Tampilkan form untuk melengkapi laporan
                with st.form("form_tambah_geotag"):
                    new_lok   = st.text_input("Nama Lokasi")
                    st.text_input("Latitude",  value=f"{exif_lat:.6f}", disabled=True)
                    st.text_input("Longitude", value=f"{exif_lon:.6f}", disabled=True)
                    new_pesan = st.text_input("Pesan Peringatan")
                    submit_lapor = st.form_submit_button("Kirim Laporan")
                
                if submit_lapor:
                    if new_lok and new_pesan:
                        # Simpan foto ke folder lokal
                        os.makedirs("foto_laporan", exist_ok=True)
                        foto_path = f"foto_laporan/{foto_upload.name}"
                        with open(foto_path, "wb") as f:
                            f.write(foto_upload.getbuffer())
                        
                        # Tambahkan entri baru ke CSV dengan status 'pending'
                        # (menunggu verifikasi admin)
                        data_baru = pd.DataFrame([{
                            "lokasi": new_lok,
                            "lat":    exif_lat,
                            "lon":    exif_lon,
                            "pesan":  new_pesan,
                            "status": "pending",   # Harus disetujui admin dulu
                            "foto":   foto_path
                        }])
                        
                        df_simpan = pd.concat([df_bahaya, data_baru], ignore_index=True)
                        df_simpan.to_csv(FILE_CSV, index=False)
                        st.success("Laporan beserta foto berhasil dikirim ke Admin.")
                    else:
                        st.error("Nama lokasi dan pesan tidak boleh kosong!")
            else:
                st.error(
                    "❌ TEKS TIDAK DITEMUKAN: "
                    "Pastikan di foto Anda tertulis angka koordinat desimal."
                )
        except Exception as e:
            st.error(f"Gagal menjalankan AI pembaca teks. Error: {e}")


# ─────────────────────────────────────────────────────────────
# BAGIAN 15: HALAMAN ADMIN (PANEL MODERASI)
# ─────────────────────────────────────────────────────────────
elif st.session_state.halaman == 'Admin':
    
    # Cegah akses jika bukan admin
    if st.session_state.role != 'Admin':
        st.error("⛔ Anda tidak memiliki akses ke halaman ini.")
    
    else:
        # Header panel admin + tombol logout
        col_judul, col_logout = st.columns([3, 1])
        col_judul.subheader("🛡️ Panel Admin")
        
        if col_logout.button("🚪 Logout"):
            st.session_state.role = 'User'
            st.session_state.halaman = 'Home'
            st.rerun()
        
        # ── Sub-bagian A: Moderasi laporan pending ──
        st.markdown("#### ⏳ Laporan Menunggu Verifikasi")
        
        # Ambil ulang data terbaru dari CSV
        df_bahaya = load_csv()
        df_pending = df_bahaya[df_bahaya['status'] == 'pending']
        
        if not df_pending.empty:
            for index, row in df_pending.iterrows():
                col_teks, col_acc, col_tolak = st.columns([3, 1, 1])
                
                # Tampilkan info laporan + link Google Maps
                info_text = (
                    f"**{row['lokasi']}** | {row['pesan']} "
                    f"[🗺️ Cek Google Maps](https://www.google.com/maps?q={row['lat']},{row['lon']})"
                )
                col_teks.info(info_text)
                
                # Tampilkan foto bukti jika ada
                if 'foto' in row and pd.notna(row['foto']) and os.path.exists(str(row['foto'])):
                    col_teks.image(row['foto'], width=250)
                
                # Tombol SETUJUI: ubah status → 'approved'
                if col_acc.button("✅ Setuju", key=f"acc_{index}"):
                    df_bahaya.at[index, 'status'] = 'approved'
                    df_bahaya.to_csv(FILE_CSV, index=False)
                    st.rerun()
                
                # Tombol TOLAK: hapus baris dari CSV
                if col_tolak.button("❌ Tolak", key=f"tolak_{index}"):
                    df_bahaya = df_bahaya.drop(index)
                    df_bahaya.to_csv(FILE_CSV, index=False)
                    st.rerun()
        else:
            st.success("✅ Aman! Tidak ada laporan pending.")
        
        # ── Sub-bagian B: Hapus titik bahaya yang sudah approved ──
        st.markdown("#### 🗑️ Cabut Titik Bahaya")
        
        # Refresh df_aktif setelah kemungkinan perubahan di atas
        df_aktif_admin = df_bahaya[df_bahaya['status'] == 'approved'].copy()
        
        if not df_aktif_admin.empty:
            with st.form("form_hapus_admin"):
                pilihan_aktif = df_aktif_admin['lokasi'].tolist()
                pilih_hapus_str = st.selectbox(
                    "Pilih lokasi yang mau dihapus:",
                    pilihan_aktif
                )
                submit_hapus = st.form_submit_button("Cabut Titik")
            
            if submit_hapus:
                # Hapus semua baris dengan nama lokasi tersebut
                df_bahaya = df_bahaya[df_bahaya['lokasi'] != pilih_hapus_str]
                df_bahaya.to_csv(FILE_CSV, index=False)
                st.success(f"Titik '{pilih_hapus_str}' berhasil dicabut dari peta!")
                st.rerun()
        else:
            st.info("Tidak ada titik bahaya aktif saat ini.")
