# 🛡️ Safe-Drive Tembalang

Aplikasi web peta titik bahaya lalu lintas di kawasan Tembalang, Semarang.  
Dibangun dengan **Python + Streamlit**.

---

## 📋 Fitur Lengkap

| Fitur | Deskripsi |
|-------|-----------|
| 🗺️ **Peta Bahaya** | Peta interaktif semua titik bahaya terverifikasi |
| 📡 **GPS Live** | Posisi user real-time dari browser |
| ⚠️ **Alarm Otomatis** | Peringatan + getar HP saat < 200m dari bahaya |
| 🧭 **Navigasi Rute** | Cari rute + deteksi bahaya di sepanjang jalur |
| 📸 **Laporan OCR** | Upload foto berkoordinat → AI baca koordinatnya |
| 🛡️ **Panel Admin** | Approve / tolak / hapus laporan masyarakat |

---

## 🚀 Cara Menjalankan

### 1. Install dependensi sistem (Tesseract OCR)
```bash
# Ubuntu/Debian
sudo apt-get install tesseract-ocr

# macOS
brew install tesseract
```

### 2. Install library Python
```bash
pip install -r requirements.txt
```

### 3. Jalankan aplikasi
```bash
streamlit run app.py
```

### 4. Buka browser
```
http://localhost:8501
```

---

## 📁 Struktur File

```
tembalangsafedrive/
├── app.py                      ← Kode utama aplikasi
├── requirements.txt            ← Dependensi Python
├── packages.txt                ← Dependensi sistem (Tesseract)
├── hasil_survei_tembalang.csv  ← Database titik bahaya
├── foto_laporan/               ← Folder foto dari pelapor (auto-dibuat)
└── README.md                   ← Dokumentasi ini
```

---

## 🗂️ Struktur CSV Database

| Kolom | Tipe | Keterangan |
|-------|------|------------|
| `lokasi` | string | Nama/deskripsi lokasi |
| `lat` | float | Latitude (contoh: -7.0512) |
| `lon` | float | Longitude (contoh: 110.4382) |
| `pesan` | string | Pesan peringatan untuk pengemudi |
| `status` | string | `approved` atau `pending` |
| `foto` | string | Path foto bukti (opsional) |

---

## 🔑 Login Admin

- **Password default:** `admin123`
- Ganti password di `app.py` baris `if pwd == "admin123":`

---

## 🌐 Deploy ke Streamlit Cloud

1. Push semua file ke GitHub
2. Buka [share.streamlit.io](https://share.streamlit.io)
3. Hubungkan repo → pilih `app.py` → Deploy
4. Streamlit Cloud otomatis baca `packages.txt` untuk install Tesseract

---

## 🧩 Teknologi yang Digunakan

- **Streamlit** — Framework web app
- **Folium** — Peta interaktif (Leaflet.js)
- **OSRM API** — Routing navigasi gratis (OpenStreetMap)
- **ArcGIS Geocoder** — Konversi nama lokasi → koordinat
- **Pytesseract** — OCR baca koordinat dari gambar
- **Web Geolocation API** — GPS real-time dari browser (JavaScript)
- **Haversine Formula** — Hitung jarak dua titik koordinat
